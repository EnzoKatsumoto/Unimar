<?php

namespace App;

class Questionario

{
    private array $enunciados = [];

    public function adicionarAoQuestionario(Perguntas $enunciado): void
    {
        $this->enunciados[] = $enunciado;
    }

    public function listarPerguntas(): void
    {
        if ($this->enunciados == []){
            echo "O questionário está vazio.";
        }

        foreach ($this->enunciados as $enunciado){
            echo $enunciado->getEnunciado() . PHP_EOL;
        }
    }
}
