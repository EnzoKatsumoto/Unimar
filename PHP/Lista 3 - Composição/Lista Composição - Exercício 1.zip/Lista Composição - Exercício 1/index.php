<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\Perguntas;

use App\Questionario;

$pergunta1 = new Perguntas();
$pergunta1->adicionarEnunciado("O Enzo é legal?");
$pergunta1->getEnunciado();
echo PHP_EOL;

$questionario1 = new Questionario();
$questionario1->adicionarAoQuestionario($pergunta1);
$questionario1->listarPerguntas() . PHP_EOL;