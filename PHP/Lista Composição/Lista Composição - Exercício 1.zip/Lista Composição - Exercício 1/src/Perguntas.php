<?php

namespace App;

use InvalidArgumentException;

class Perguntas

{
    private string $enunciado;
    private string $respostaEsperada;
    public function __construct()
    {
        $this->enunciado = "";
        $this->respostaEsperada = "";
    }

    public function adicionarEnunciado(string $enun): bool

    {
        if ($enun == ""){
            echo "O enunciado não deve ficar em branco." . PHP_EOL;
            return false;
        }

        $this->enunciado = $enun;
        echo "Enunciado adicionado com sucesso." . PHP_EOL;
        return true;
    }

    public function respostaEsperada(string $resposta): bool

    {
        if ($resposta = ""){
            echo "A resposta não deve ficar em branco." . PHP_EOL;
            return false;
        }

        $this->respostaEsperada = $resposta;
        echo "Resposta adicionada." . PHP_EOL;
        return true;
    }

    public function getEnunciado(): void
    {
        echo "$this->enunciado";
    }
}

