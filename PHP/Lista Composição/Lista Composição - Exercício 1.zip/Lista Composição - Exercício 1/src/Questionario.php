<?php

namespace App;

class Questionario

{
    private array $enunciados;

    public function __construct(
        private string $titulo
    ){
        $this->enunciados = [];
    }

    public function adicionarAoQuestionario(Perguntas $enunciado): void
    {
        $this->enunciados[] = $enunciado;
    }

    public function listarPerguntas(): void
    {
        if ($this->enunciados == []){
            echo "O questionário está vazio.";
        }

        foreach ($this->enunciados as $enunciado){
            echo $enunciado->getEnunciado() . PHP_EOL;
        }
    }

        public function qtdPerguntas(): int
    {
        $contador = 0;

        foreach ($this->enunciados as $enunciado){
            $contador++;
        }
        return $contador;
    }

    public function resumo(): string
    {
        return "{$this->titulo} - Total de perguntas: {$this->qtdPerguntas()}" . PHP_EOL;
    }

}
