<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\Perguntas;

use App\Questionario;

$pergunta1 = new Perguntas();
$pergunta1->adicionarEnunciado("Quanto é o valor aproximado de pi?");
$pergunta1->respostaEsperada("3,14");

$pergunta2 = new Perguntas();
$pergunta2->adicionarEnunciado("Qual é o único número primo par?");
$pergunta2->respostaEsperada("2");

$questionario1 = new Questionario("Prova de Matemática");
$questionario1->adicionarAoQuestionario($pergunta1);
$questionario1->adicionarAoQuestionario($pergunta2);
echo $questionario1->resumo();
$questionario1->listarPerguntas();